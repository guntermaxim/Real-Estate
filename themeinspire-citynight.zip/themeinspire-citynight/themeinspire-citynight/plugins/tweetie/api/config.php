<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'kGbJ8dEg7jiiZGYrE0SFbhJ17');
    define('CONSUMER_SECRET', 'JIIFIyA5tj6VI9uyor951VH5dOOxcs3zSfSscuyNv1ehC2warP');

    // User Access Token
    define('ACCESS_TOKEN', '3118331359-zZXXJsv9Ih0vR7brswvWTg6FHNDaqw8p81Xm2wr');
    define('ACCESS_SECRET', 'sVC2kdtwhhsxfby7dl8XPpseyO4GgRBbXOgzbsU4SEbEv');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));